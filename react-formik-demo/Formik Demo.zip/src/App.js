import './App.css';
import OldYoutubeForm from './components/OldYoutubeForm';
import YoutubeForm from './components/YoutubeForm';

function App() {
  return (
    <div className="App">
      {/* <OldYoutubeForm /> */}
      <YoutubeForm/>
    </div>
  );
}

export default App;
